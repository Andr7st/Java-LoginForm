# Andr7st

Directorio opcional para Entorno de ejecución de Java / Java Runtime Environment.

**Mínimo requerido:** OpenJDK Java1.8

---
Usando **Run.exe** by Andr7st. Creado por https://github.com/Andr7st 

Run.exe: Muestra una ventana y que se ocultará mientras se use el programa.
Run-c.exe : Llama una ventana cmd que se ejecutará mientras este corriendo el programa. 

Dado el caso de que el sistema windows no tenga JAVA_HOME configurado, 
**Run.exe** intentará ejecutar el runtime guardado en este directorio.

El runtime se podrá descargar desde la página oficial de java o OpenJDK, Amazon corretto, AdoptJDK, etc.