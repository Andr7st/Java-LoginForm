# Andr7st - Demostración --version 1.

  Demostración: Para ejecutarlo mediante **Run.exe** en windows es 
  necesario tener instalado Java y que esté configurado el JAVA_HOME
  o ejecutar en la consola $ Java -jar "Main.jar"

  Esto es una demostración y podria no tener las últimas actualizaciones
  del código.

# Andrés en github:

  https://github.com/Andr7st/
  https://github.com/Andr7st/index/
